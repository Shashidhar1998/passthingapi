from django.contrib.auth import login, authenticate
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from .serializers import RegistrationSerializer
from django.contrib.auth import authenticate
from django.views.decorators.csrf import csrf_exempt
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.status import (
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
    HTTP_200_OK
)
from Accounts.models import User

@csrf_exempt
@api_view(['POST',])
@permission_classes((AllowAny,))
def Registrationsview(request):
    if request.method  == 'POST':
        serializer = RegistrationSerializer(data=request.data)
        data = {}
        if serializer.is_valid():
            user_obj = serializer.save()
            data['response'] = "Successfully Registered"
            data['email'] = user_obj.email
            data['username'] = user_obj.username
            data ['status'] = HTTP_200_OK
        else:
            data = serializer.errors
            data ['status'] = HTTP_400_BAD_REQUEST
        return Response(data)


@csrf_exempt
@api_view(["POST"])
@permission_classes((AllowAny,))
def login(request):
    username = request.data.get("username")
    password = request.data.get("password")
    if username is None or password is None:
        return Response({'error': 'Please provide both username and password'},
                        status=HTTP_400_BAD_REQUEST)
    user = authenticate(username=username, password=password)
    if not user:
        return Response({'error': 'Invalid Credentials'},
                        status=HTTP_404_NOT_FOUND)
    token, _ = Token.objects.get_or_create(user=user)
    return Response({'token': token.key,'Staff Access':user.staff,'Admin Access':user.admin},
                    status=HTTP_200_OK)

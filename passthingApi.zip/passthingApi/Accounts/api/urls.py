from django.urls import path
from django.conf.urls import url,include
from rest_framework.authtoken.views import obtain_auth_token
from . import views 
urlpatterns = [
    path('user/signup', views.Registrationsview, name='usersignup'),
    path('user/signin', views.login, name='usersignin'),
    path('admin/signin', obtain_auth_token, name='adminsignin'),
]
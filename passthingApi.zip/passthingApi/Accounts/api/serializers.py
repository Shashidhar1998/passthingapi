from rest_framework import serializers
from Accounts.models import User,UserManager
from .generators import Generators

class RegistrationSerializer(serializers.ModelSerializer):
    password2 = serializers.CharField(style={'input_type': 'password'}, write_only=True)
    class Meta:
        model = User
        fields = ['username','email','phonenumber','password','password2','first_name','last_name']
        extra_kwargs = {
            'password' : {'write_only':True},
        }

    def save(self, first_name=None, last_name=None, active=False, staff=False, admin=False, *args,  **kwargs):
        if not self.validated_data['email']:
            raise serializers.ValidationError({'Email': 'Users must have email'})

        if not self.validated_data['phonenumber']:
            raise serializers.ValidationError({'Phone Number': 'Users must have phonenumber'})

        if not self.validated_data['password']:
            raise serializers.ValidationError({'password': 'Please Enter the Password'})

        if self.validated_data['password'] != self.validated_data['password2']:
            raise serializers.ValidationError({'password': 'Both Passwords should be same' })

        if not self.validated_data['username']:
            raise serializers.ValidationError({'username': 'Users must have username'})

        user_obj = User(
            email = self.validated_data['email'],
            phonenumber = self.validated_data['phonenumber'],
            username = self.validated_data['username'],
            first_name = self.validated_data['first_name'],
            last_name = self.validated_data['last_name'],
        )
        user_obj.set_password(self.validated_data['password'])
        user_obj.active = True
        user_obj.staff = True
        try:
            Generators.sendmailtoregistration(user_obj.email)
            user_obj.save()
        except:
            raise serializers.ValidationError({'message': 'unable to send message'})
        # UserManager.create_superuser(self,user_obj.email,phone, user_obj.username, user_obj.password)
        return user_obj
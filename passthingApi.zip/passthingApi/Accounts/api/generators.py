import smtplib
import math, random

class Generators:
    def generateOTP() :
        digits = "0123456789"
        OTP = ""
        for i in range(6) :
            OTP += digits[math.floor(random.random() * 10)] 
        return OTP
    def sendmailtoregistration(senderemail):
        mail = smtplib.SMTP('smtp.gmail.com',587)
        mail.ehlo()
        mail.starttls()
        mail.login('developmentshashi@gmail.com','Shashi@123')
        subject = 'Passthing Verification'
        verificationcode = Generators.generateOTP()
        body = 'Welcome to Passthing \n You verification code : ' + verificationcode
        content = f'Subject: {subject}\n\n{body}'
        mail.sendmail('developmentshashi@gmail.com',senderemail,content)
        mail.quit()
from django.db import models
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser
)

# Create your models here.
class UserManager(BaseUserManager):

    def create_user(self, email, phonenumber, username, password, first_name=None, last_name=None, is_active = True, is_staff = False, is_admin = False, *args,  **kwargs):
        if not email:
            raise ValueError('Users must have an email address')

        if not phonenumber:
            raise ValueError('Users must have Phone Number')

        if not password:
            raise ValueError('Users must have Password')

        if not username:
            raise ValueError('Users must have Username')

        user_obj = self.model(
            email=self.normalize_email(email),
        )
        user_obj.set_password(password)
        user_obj.username = username
        user_obj.phonenumber=phonenumber
        user_obj.active = is_active
        user_obj.staff = is_staff
        user_obj.admin = is_admin
        user_obj.save(using=self._db)
        return user_obj

    def create_staffuser(self, email, phonenumber, username, password, first_name=None, last_name=None, is_active = True, is_staff = False, is_admin = False, *args,  **kwargs):
        user_obj = self.create_user(
            email,
            phonenumber = phonenumber,
            username = username,
            password=password,
            is_staff = True,

        )
        user_obj.staff = True
        user_obj.save(using=self._db)
        return user_obj

    def create_superuser(self, email, phonenumber, username, password, first_name=None, last_name=None, is_active = True, is_staff = False, is_admin = False, *args,  **kwargs):
        user_obj = self.create_staffuser(
            email,
            phonenumber = phonenumber,
            username = username,
            password=password,
            is_staff = True,
            is_admin = True

        )
        user_obj.admin = True
        user_obj.save(using=self._db)
        return user_obj



class User(AbstractBaseUser):
    first_name = models.CharField(max_length=30,blank=True)
    last_name = models.CharField(max_length=30,blank=True)
    email = models.EmailField(
        verbose_name='email address',
        max_length=255,
        unique=True,
    )
    username = models.CharField(verbose_name='Username',max_length=30,unique=True)
    phonenumber =  models.CharField(max_length=15,unique=True)
    active = models.BooleanField(default=True)
    staff = models.BooleanField(default=False) # a admin user; non super-user
    admin = models.BooleanField(default=False) # a superuser
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['phonenumber','username']
    objects = UserManager()

    def get_email(self):
        # The user is identified by their email address
        return self.email

    def __str__(self):              # __unicode__ on Python 2
        return str(self.id)+"     "+self.email

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        return self.staff

    @property
    def is_admin(self):
        "Is the user a admin member?"
        return self.admin

    @property
    def is_active(self):
        "Is the user active?"
        return self.active